package com.example.arithmetic;// Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.arithmetic.R;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText input1;
    private EditText input2;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        input1 = findViewById(R.id.editTextNumber);
        input2 = findViewById(R.id.editTextNumber2);
        resultTextView = findViewById(R.id.textView);

        // Set up buttons
        Button addButton = findViewById(R.id.button);
        Button subtractButton = findViewById(R.id.button2);
        Button multiplyButton = findViewById(R.id.button3);
        Button divideButton = findViewById(R.id.button4);

        // Set click listeners for buttons
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation('+');
            }
        });

        subtractButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation('-');
            }
        });

        multiplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation('*');
            }
        });

        divideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation('/');
            }
        });
    }

    private void performOperation(char operator) {
        // Get input values
        double num1 = Double.parseDouble(input1.getText().toString());
        double num2 = Double.parseDouble(input2.getText().toString());

        // Perform the selected operation
        double result;
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                result = (num2 != 0.0) ? num1 / num2 : Double.NaN;
                break;
            default:
                result = Double.NaN;
        }

        // Display the result
        resultTextView.setText("Result: " + result);
    }
}
